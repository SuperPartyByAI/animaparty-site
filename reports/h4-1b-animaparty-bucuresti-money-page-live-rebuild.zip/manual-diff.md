Added 20 custom FAQs for Bucharest. Rewrote entire Bucuresti Astro page to use strict local UX without cannibalizing the homepage.
