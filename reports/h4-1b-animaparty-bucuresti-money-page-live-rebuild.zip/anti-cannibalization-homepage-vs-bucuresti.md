# Anti Cannibalization Report
Homepage remains the generic Brand Hub for 'Bucuresti si Ilfov'. This page strictly limits to 'Sectoarele 1-6', 'Deplasare in oras', 'Apartament/Bloc'. H1, Title, and 20 FAQs are entirely distinct from the homepage.
