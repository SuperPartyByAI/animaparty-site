All tests performed against the live VPS deployment IP 89.167.115.150. Local environment discarded.
