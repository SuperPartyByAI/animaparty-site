# Diff
Replaced 'garanta' and expanded FAQs.
