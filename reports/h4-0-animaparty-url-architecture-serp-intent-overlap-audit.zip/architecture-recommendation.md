# Architecture Recommendation

1. Maintain homepage for primary broad intent (animatori Bucuresti / animatori petreceri copii).
2. Build Service Hub (Face Painting, Baloane, Mascote).
3. Build Location Hub (Ilfov, Sectoare dacă volumele și SERP-ul dovedesc intenție separată).
