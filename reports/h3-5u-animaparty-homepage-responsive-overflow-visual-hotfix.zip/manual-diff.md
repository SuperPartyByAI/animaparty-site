# Diff
Added HTML/body width 100% and overflow-x hidden. Replaced minmax(px) with minmax(min(100%, px)). Fixed flex-wrap on packages.
