# GSC Manual Action

Request Indexing in GSC for https://animaparty.ro/
