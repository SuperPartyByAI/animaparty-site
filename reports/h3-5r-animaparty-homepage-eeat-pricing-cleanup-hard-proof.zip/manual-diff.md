# Diff
Replaced garantat with ridicat in pricing.ts. Expanded FAQ to 20 questions in faqHome.ts and schema.ts.
