# Hold Recommendations
Both money pages (/animatori-petreceri-copii/ and /animatori-petreceri-copii-bucuresti/) should NOT be submitted to GSC until they are fully rebuilt and verified against top 10 SERP, to prevent them from cannibalizing the homepage.
