Added fallback tailwind classes .h-6 and .w-6 to lock SVG icon sizes to 1.5rem (24px) globally, fixing the massive SVG visual bug.
