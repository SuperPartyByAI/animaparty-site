# No Deep Pages Note

No deep internal service pages exist yet. All internal links added are anchor links within the homepage (e.g., /#informatii-utile, /#galerie).
