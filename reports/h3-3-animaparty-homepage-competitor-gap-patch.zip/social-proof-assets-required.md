# Social Proof Assets Required

No real testimonials, reviews, or team experience numbers were found in the codebase. To complete the social proof layer, the following assets are required:
- 3-6 text reviews from real clients (ideally with first names and event context).
- A link to the Google Business Profile to show aggregated rating.
- Specific data regarding experience (e.g., 'peste X evenimente' or 'de Y ani pe piata').
