# GSC Action Needed

Please submit both URLs for indexing in Google Search Console.
