Icon sizes fixed to max 40x40 (36x36 mobile).
