All tests performed against the live VPS deployment. Local environment discarded.
